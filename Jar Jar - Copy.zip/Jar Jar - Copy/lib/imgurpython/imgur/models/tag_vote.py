class TagVote(object):

    def __init__(self, ups, downs, name, author):
        self.ups = ups
        self.downs = downs
        self.name = name
        self.author = author
